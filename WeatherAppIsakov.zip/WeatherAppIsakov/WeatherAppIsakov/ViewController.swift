//
//  ViewController.swift
//  WeatherAppIsakov
//
//  Created by Student on 16.02.2022.
//

import UIKit
import Alamofire
import SwiftyJSON

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var cityTableView: UITableView!
    @IBAction func searchCityAction(_ sender: Any) {
        let alert = UIAlertController(title: "Enter city", message: "Enter in english!", preferredStyle: .alert)
        alert.addTextField { textField in
            textField.placeholder = "City"
        }
        let submit = UIAlertAction(title: "Find", style: .default) { action in
            self.getWeather(city: alert.textFields![0].text!)
        }
        let cancel = UIAlertAction(title: "close", style: .cancel, handler: nil)
        alert.addAction(submit)
        alert.addAction(cancel)
        present(alert, animated: true, completion: nil)
    }
    var cityArray: [String] = []
    var tempArray: [String] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        cityTableView.delegate = self
        cityTableView.dataSource = self
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cityCell", for: indexPath) as! CityTableViewCell
        
        cell.cityNameLabel.text = cityArray[indexPath.row]
        cell.cityTempLabel.text = tempArray[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsAtSection Section: Int) -> Int {
        return cityArray.count
    }
    
    func getWeather(city: String) {
        let url = "http://api.weatherapi.com/v1/current.json?key=49acf8b477c24688fb4660624212909&q=\(city)"
        AF.request(url, method: .get).validate().responseJSON { response in
            switch response.result {
            case .success(let value):
                let json = JSON(value)
                print("JSON: \(json)")
                self.cityArray.append(json["location"]["name"].stringValue)
                self.tempArray.append(json["current"]["temp_c"].stringValue)
            case .failure(let error):
                print(error)
            }
        }
    }

}

